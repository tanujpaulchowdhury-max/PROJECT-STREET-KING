# PROJECT STREET KING — Godot 4 vertical slice

Original Android-oriented third-person driving prototype set in SUNCOAST CITY.

## What is implemented in source
- Godot 4 project configured for the Mobile/Compatibility (GL Compatibility) renderer.
- Runtime-built coastal street district with asphalt roads, sidewalks, lane markings, building silhouettes, facade windows, streetlights, palms and ocean horizon.
- Original red sports-coupe placeholder assembled from meshes; four `VehicleWheel3D` physics wheels and a `VehicleBody3D` controller.
- Smooth chase camera with desktop right-mouse orbit and touch-drag orbit.
- Touchscreen GAS/BRAKE/steering buttons and keyboard WASD/arrow input.
- Simple delivery objective, distance readout, destination ring and $500 completion reward.

## Requirements
- Godot Engine 4.2 or newer. No Godot executable, Blender, Android SDK, ADB, or GPU tooling was present in the authoring container, so the project could not be launched or exported here.
- For Android export, install Godot export templates and Android SDK/JDK, configure them in Editor Settings, then use Project > Export.

## Run
Open this folder (`project.godot`) in Godot 4 and press F6/F5. The world is generated at runtime; no downloaded third-party assets are required.

## Controls
- W / Up: accelerate
- S / Down: brake/reverse
- A / Left and D / Right: steer
- Right mouse drag: orbit camera in desktop testing
- Touch GAS/BRAKE and ◀/▶ buttons on mobile
- Drag the upper screen area to orbit camera

## Known limitations (honest status)
- The coupe and buildings are procedural mesh prototypes, not photorealistic imported assets.
- No rigged walking character, traffic, pedestrians, police, audio, save system, or graphics settings yet.
- Runtime geometry is intentionally small and unstreamed; expand only after engine validation and device profiling.
- Godot runtime, static parser, gameplay, Android export and device installation tests have **not** been run in the current environment.

## Project layout
- `project.godot` — engine and input configuration
- `scenes/main.tscn` — startup scene
- `scripts/main.gd` — procedural city, vehicle, mission and mobile HUD
- `scripts/vehicle_controller.gd` — vehicle input and tuning
- `scripts/chase_camera.gd` — camera follow and orbit
- `scripts/mission_manager.gd` — data-driven starter mission state
- `docs/STATUS.md` — implementation/test ledger
