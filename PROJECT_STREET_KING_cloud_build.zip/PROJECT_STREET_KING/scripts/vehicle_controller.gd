extends VehicleBody3D
## Tunable vehicle handling; uses Godot's actual VehicleBody3D and VehicleWheel3D physics.
@export var max_engine_force: float = 1350.0
@export var max_brake_force: float = 42.0
@export var max_steering_angle: float = 0.42
@export var steering_response: float = 2.8
@export var max_speed_kmh: float = 155.0
var steering_input := 0.0
var throttle_input := 0.0
var brake_input := 0.0

func _physics_process(delta: float) -> void:
	var touch := get_parent().get("touch_controls")
	var left := Input.is_action_pressed("steer_left") or (touch != null and touch.left)
	var right := Input.is_action_pressed("steer_right") or (touch != null and touch.right)
	var gas := Input.is_action_pressed("accelerate") or (touch != null and touch.accelerate)
	var brake := Input.is_action_pressed("brake") or (touch != null and touch.brake)
	var desired_steer := float(right) - float(left)
	steering_input = move_toward(steering_input, desired_steer, steering_response * delta)
	throttle_input = 1.0 if gas else 0.0
	brake_input = 1.0 if brake else 0.0
	steering = steering_input * max_steering_angle
	var speed_kmh := linear_velocity.length() * 3.6
	engine_force = max_engine_force * throttle_input if speed_kmh < max_speed_kmh else 0.0
	brake = max_brake_force * brake_input
	if brake and linear_velocity.dot(-global_transform.basis.z) < -1.0:
		engine_force = -max_engine_force * 0.45
