extends Node
var destination := Vector3.ZERO
var reward := 500
var mission_title := "COASTLINE COURIER"
var description := "Drive to the marked destination."
var completed := false
var cash := 0

func configure(target: Vector3, reward_amount: int, title: String, details: String) -> void:
	destination = target
	reward = reward_amount
	mission_title = title
	description = details

func complete_mission() -> void:
	if completed:
		return
	completed = true
	cash += reward
	print("Mission complete: %s | reward $%d | cash $%d" % [mission_title, reward, cash])
