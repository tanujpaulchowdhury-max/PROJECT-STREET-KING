extends Camera3D
@export var follow_distance: float = 7.2
@export var follow_height: float = 3.1
@export var follow_smoothing: float = 5.5
@export var look_height: float = 0.8
var target: Node3D
var orbit_yaw := 0.0
var orbit_pitch := -0.10
var drag_active := false
var last_pointer := Vector2.ZERO

func _ready() -> void:
	current = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_RIGHT:
			drag_active = event.pressed
	elif event is InputEventMouseMotion and drag_active:
		orbit_yaw -= event.relative.x * 0.004
		orbit_pitch = clamp(orbit_pitch - event.relative.y * 0.003, -0.42, 0.28)
	elif event is InputEventScreenDrag:
		# Drag the upper/central screen area to orbit; HUD buttons remain independently interactive.
		if event.position.y < get_viewport().get_visible_rect().size.y * 0.68:
			orbit_yaw -= event.relative.x * 0.004
			orbit_pitch = clamp(orbit_pitch - event.relative.y * 0.003, -0.42, 0.28)

func _process(delta: float) -> void:
	if not is_instance_valid(target):
		return
	var forward := -target.global_transform.basis.z
	var rotated_forward := forward.rotated(Vector3.UP, orbit_yaw)
	var desired := target.global_position - rotated_forward * follow_distance + Vector3.UP * follow_height
	desired += Vector3.UP * (orbit_pitch * 2.0)
	global_position = global_position.lerp(desired, 1.0 - exp(-follow_smoothing * delta))
	look_at(target.global_position + Vector3.UP * look_height, Vector3.UP)
