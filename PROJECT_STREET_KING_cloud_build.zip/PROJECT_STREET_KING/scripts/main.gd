extends Node3D
## Runtime-built vertical slice: original coastal city block, vehicle, chase camera and touch HUD.

const VehicleScript = preload("res://scripts/vehicle_controller.gd")
const CameraScript = preload("res://scripts/chase_camera.gd")
const MissionScript = preload("res://scripts/mission_manager.gd")

var car: VehicleBody3D
var chase_camera: Camera3D
var mission_manager: Node
var hud: CanvasLayer
var speed_label: Label
var objective_label: Label
var distance_label: Label
var toast_label: Label
var destination := Vector3(0, 0, -115)
var touch_controls := {"accelerate": false, "brake": false, "left": false, "right": false}
var elapsed := 0.0

func _ready() -> void:
	_setup_world()
	_build_city()
	_build_vehicle()
	_build_mission()
	_build_hud()
	print("PROJECT STREET KING: vertical slice initialized")

func _process(delta: float) -> void:
	elapsed += delta
	if is_instance_valid(car):
		var kmh := int(car.linear_velocity.length() * 3.6)
		speed_label.text = "%03d  KM/H" % kmh
		var d := car.global_position.distance_to(destination)
		distance_label.text = "%d m TO DROP" % int(d)
		if d < 7.0 and not mission_manager.completed:
			mission_manager.complete_mission()
			toast_label.text = "DELIVERY COMPLETE  +$500"
			toast_label.visible = true
		elif mission_manager.completed:
			objective_label.text = "DELIVERY COMPLETE — EXPLORE SUNCOAST CITY"

func _setup_world() -> void:
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.12, 0.29, 0.48)
	sky_mat.sky_horizon_color = Color(0.78, 0.78, 0.68)
	sky_mat.ground_bottom_color = Color(0.12, 0.14, 0.15)
	sky_mat.ground_horizon_color = Color(0.48, 0.50, 0.48)
	sky.sky_material = sky_mat
	e.sky = sky
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.58, 0.65, 0.72)
	e.ambient_light_energy = 0.7
	e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	e.fog_enabled = true
	e.fog_light_color = Color(0.63, 0.72, 0.75)
	e.fog_density = 0.0018
	env.environment = e
	add_child(env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-42, -28, 0)
	sun.light_energy = 1.35
	sun.shadow_enabled = true
	add_child(sun)

func _build_city() -> void:
	# Main avenue, perpendicular streets and sidewalks; all dimensions are in metres.
	_box("Asphalt Main Avenue", Vector3(0, -0.16, -40), Vector3(18, 0.3, 180), Color(0.105, 0.12, 0.13), true)
	_box("Cross Street North", Vector3(0, -0.15, -92), Vector3(105, 0.3, 12), Color(0.12, 0.13, 0.14), true)
	_box("Cross Street South", Vector3(0, -0.15, 12), Vector3(105, 0.3, 12), Color(0.12, 0.13, 0.14), true)
	for side in [-1, 1]:
		_box("Concrete Sidewalk", Vector3(side * 11.5, 0.0, -40), Vector3(4.5, 0.35, 180), Color(0.49, 0.50, 0.47), true)
		for z in range(-120, 51, 12):
			_box("Lane Dash", Vector3(0, 0.015, z), Vector3(0.16, 0.035, 4.2), Color(0.88, 0.83, 0.64), false)
		for z in range(-115, 45, 24):
			_box("Kerb Stripe", Vector3(side * 9.1, 0.025, z), Vector3(0.16, 0.06, 5), Color(0.88, 0.87, 0.78), false)
	# Waterfront glint and distant coastal horizon.
	_box("Ocean", Vector3(0, -1.1, -155), Vector3(500, 0.2, 45), Color(0.10, 0.35, 0.48), false)
	var palettes := [Color(0.67,0.61,0.51), Color(0.43,0.52,0.56), Color(0.72,0.69,0.60), Color(0.36,0.42,0.45), Color(0.73,0.55,0.39)]
	var rng := RandomNumberGenerator.new()
	rng.seed = 27041
	for side in [-1, 1]:
		for i in range(8):
			var z := -112.0 + float(i) * 22.0
			var width := rng.randf_range(11.0, 17.0)
			var depth := rng.randf_range(13.0, 19.0)
			var height := rng.randf_range(10.0, 30.0)
			var x := side * rng.randf_range(24.0, 36.0)
			_build_building(Vector3(x, height * 0.5, z), Vector3(width, height, depth), palettes[rng.randi_range(0, palettes.size()-1)], rng)
	# Streetlights, planters and palms provide foreground scale cues.
	for side in [-1, 1]:
		for z in range(-112, 42, 22):
			var pole := _box("Streetlight Pole", Vector3(side * 8.3, 3.1, z), Vector3(0.16, 6.2, 0.16), Color(0.16,0.18,0.19), false)
			_box("Streetlight Arm", Vector3(side * 7.8, 6.0, z), Vector3(1.1,0.12,0.12), Color(0.16,0.18,0.19), false)
			var lamp := _box("Warm Street Lamp", Vector3(side * 7.25, 5.85, z), Vector3(0.55,0.16,0.42), Color(1.0,0.78,0.43), false)
			var mat: StandardMaterial3D = lamp.get_surface_override_material(0)
			mat.emission_enabled = true
			mat.emission = Color(1.0,0.55,0.22)
		for z in range(-104, 30, 34):
			_create_palm(Vector3(side * 13.2, 0, z))
	# Mission destination ring.
	var marker := MeshInstance3D.new()
	var torus := TorusMesh.new()
	torus.inner_radius = 2.5
	torus.outer_radius = 3.0
	marker.mesh = torus
	marker.position = destination + Vector3(0, 0.25, 0)
	var mm := StandardMaterial3D.new()
	mm.albedo_color = Color(0.1, 0.95, 0.78, 0.8)
	mm.emission_enabled = true
	mm.emission = Color(0.05, 0.8, 0.55)
	mm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	marker.material_override = mm
	add_child(marker)

func _build_building(pos: Vector3, size: Vector3, color: Color, rng: RandomNumberGenerator) -> void:
	_box("Suncoast Building", pos, size, color, true)
	# Simple facade rhythm with inset dark windows rather than featureless blocks.
	var floors := int(size.y / 3.2)
	var columns := int(size.x / 2.8)
	for floor in range(1, floors):
		for col in range(max(1, columns)):
			var wx := pos.x - size.x * 0.5 + 1.3 + col * (size.x - 2.0) / max(1, columns)
			var wz := pos.z - size.z * 0.5 - 0.09
			var win_h := 1.45
			_box("Facade Window", Vector3(wx, floor * 3.0, wz), Vector3(1.35, win_h, 0.08), Color(0.075,0.16,0.20), false)
			if rng.randf() > 0.82:
				_box("Lit Window", Vector3(wx, floor * 3.0, wz - 0.055), Vector3(0.92, 1.0, 0.035), Color(0.85,0.68,0.39), false)
	# rooftop parapet gives silhouettes some variation
	_box("Roof Parapet", pos + Vector3(0, size.y * 0.5 + 0.35, 0), Vector3(size.x + 0.25, 0.7, size.z + 0.25), color.darkened(0.16), false)

func _create_palm(pos: Vector3) -> void:
	_box("Palm Trunk", pos + Vector3(0, 2.1, 0), Vector3(0.45, 4.2, 0.45), Color(0.38,0.25,0.14), false)
	for i in range(7):
		var a := TAU * float(i) / 7.0
		var leaf := _box("Palm Frond", pos + Vector3(cos(a)*1.25, 4.1, sin(a)*1.25), Vector3(0.35,0.12,2.8), Color(0.16,0.35,0.20), false)
		leaf.rotation.y = -a
		leaf.rotation.z = -0.22

func _box(label: String, pos: Vector3, size: Vector3, color: Color, collision: bool) -> MeshInstance3D:
	var root: Node3D = self
	var mesh_instance := MeshInstance3D.new()
	mesh_instance.name = label
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh_instance.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.82
	mesh_instance.material_override = mat
	mesh_instance.position = pos
	root.add_child(mesh_instance)
	if collision:
		var body := StaticBody3D.new()
		body.name = label + " Collision"
		body.position = pos
		var shape_node := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = size
		shape_node.shape = shape
		body.add_child(shape_node)
		add_child(body)
	return mesh_instance

func _build_vehicle() -> void:
	car = VehicleBody3D.new()
	car.name = "StreetKing_SportCoupe"
	car.position = Vector3(0, 1.0, -2)
	car.mass = 1150.0
	car.script = VehicleScript
	var chassis := BoxMesh.new()
	chassis.size = Vector3(1.85, 0.55, 4.0)
	var body_mesh := MeshInstance3D.new()
	body_mesh.name = "Original Coupe Body"
	body_mesh.mesh = chassis
	var paint := StandardMaterial3D.new()
	paint.albedo_color = Color(0.72, 0.08, 0.055)
	paint.metallic = 0.72
	paint.roughness = 0.24
	body_mesh.material_override = paint
	body_mesh.position.y = 0.45
	car.add_child(body_mesh)
	var cabin := MeshInstance3D.new()
	var cabin_mesh := BoxMesh.new()
	cabin_mesh.size = Vector3(1.35, 0.48, 1.75)
	cabin.mesh = cabin_mesh
	var glass := StandardMaterial3D.new()
	glass.albedo_color = Color(0.055,0.12,0.16)
	glass.metallic = 0.45
	glass.roughness = 0.16
	cabin.material_override = glass
	cabin.position = Vector3(0, 0.91, -0.12)
	car.add_child(cabin)
	# Wheel nodes are real VehicleWheel3D physics wheels, with separate visible cylinders.
	for spec in [{"n":"FL","p":Vector3(-0.92,0.0,-1.28),"steer":true},{"n":"FR","p":Vector3(0.92,0.0,-1.28),"steer":true},{"n":"RL","p":Vector3(-0.92,0.0,1.28),"steer":false},{"n":"RR","p":Vector3(0.92,0.0,1.28),"steer":false}]:
		var wheel := VehicleWheel3D.new()
		wheel.name = "Wheel_" + spec.n
		wheel.position = spec.p
		wheel.use_as_steering = spec.steer
		wheel.use_as_traction = true
		wheel.wheel_radius = 0.36
		wheel.wheel_rest_length = 0.18
		wheel.suspension_stiffness = 28.0
		wheel.damping_compression = 0.45
		wheel.damping_relaxation = 0.55
		wheel.wheel_friction_slip = 3.0
		car.add_child(wheel)
		var visual := MeshInstance3D.new()
		visual.name = "Wheel Visual"
		var cylinder := CylinderMesh.new()
		cylinder.top_radius = 0.34
		cylinder.bottom_radius = 0.34
		cylinder.height = 0.22
		visual.mesh = cylinder
		visual.rotation_degrees.z = 90
		var rubber := StandardMaterial3D.new()
		rubber.albedo_color = Color(0.035,0.04,0.045)
		rubber.roughness = 0.95
		visual.material_override = rubber
		wheel.add_child(visual)
	var cs := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(1.75, 0.65, 3.8)
	cs.shape = box
	cs.position.y = 0.43
	car.add_child(cs)
	add_child(car)
	chase_camera = Camera3D.new()
	chase_camera.name = "Driving Chase Camera"
	chase_camera.current = true
	chase_camera.fov = 72.0
	chase_camera.script = CameraScript
	# The camera follows a direct target reference assigned after it enters the scene tree.
	add_child(chase_camera)
	chase_camera.target = car

func _build_mission() -> void:
	mission_manager = Node.new()
	mission_manager.name = "MissionManager"
	mission_manager.set_script(MissionScript)
	add_child(mission_manager)
	mission_manager.configure(destination, 500, "COASTLINE COURIER", "Drive to the glowing drop-off marker.")

func _build_hud() -> void:
	hud = CanvasLayer.new()
	hud.name = "MobileHUD"
	add_child(hud)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.add_child(root)
	var title := Label.new()
	title.text = "SUNCOAST CITY  /  STREET KING"
	title.position = Vector2(24, 20)
	title.add_theme_font_size_override("font_size", 20)
	title.add_theme_color_override("font_color", Color(0.86,0.96,0.94))
	root.add_child(title)
	objective_label = Label.new()
	objective_label.text = "COASTLINE COURIER  —  FOLLOW THE MARKER"
	objective_label.position = Vector2(24, 53)
	objective_label.add_theme_font_size_override("font_size", 17)
	root.add_child(objective_label)
	distance_label = Label.new()
	distance_label.position = Vector2(24, 81)
	distance_label.add_theme_font_size_override("font_size", 16)
	root.add_child(distance_label)
	speed_label = Label.new()
	speed_label.text = "000  KM/H"
	speed_label.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	speed_label.position = Vector2(-230, -95)
	speed_label.size = Vector2(200, 50)
	speed_label.add_theme_font_size_override("font_size", 28)
	speed_label.add_theme_color_override("font_color", Color(0.45,1.0,0.82))
	root.add_child(speed_label)
	toast_label = Label.new()
	toast_label.visible = false
	toast_label.text = "DELIVERY COMPLETE"
	toast_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	toast_label.position = Vector2(-180, 115)
	toast_label.size = Vector2(360, 45)
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.add_theme_font_size_override("font_size", 22)
	root.add_child(toast_label)
	_add_touch_button(root, "◀", Vector2(35,-130), "left", Control.PRESET_BOTTOM_LEFT, Vector2(80,80))
	_add_touch_button(root, "▶", Vector2(125,-130), "right", Control.PRESET_BOTTOM_LEFT, Vector2(80,80))
	_add_touch_button(root, "BRAKE", Vector2(-255,-130), "brake", Control.PRESET_BOTTOM_RIGHT, Vector2(105,80))
	_add_touch_button(root, "GAS", Vector2(-135,-130), "accelerate", Control.PRESET_BOTTOM_RIGHT, Vector2(105,80))
	var hint := Label.new()
	hint.text = "WASD / ARROWS  •  Touch buttons to drive"
	hint.position = Vector2(24, 112)
	hint.add_theme_font_size_override("font_size", 13)
	hint.add_theme_color_override("font_color", Color(0.8,0.84,0.84))
	root.add_child(hint)

func _add_touch_button(parent: Control, caption: String, offset: Vector2, action: String, preset: Control.LayoutPreset, button_size: Vector2) -> void:
	var b := Button.new()
	b.text = caption
	b.size = button_size
	b.add_theme_font_size_override("font_size", 20)
	b.add_theme_color_override("font_color", Color(0.95,0.98,0.97))
	var normal := StyleBoxFlat.new()
	normal.bg_color = Color(0.025,0.055,0.07,0.78)
	normal.border_color = Color(0.2,0.85,0.72,0.9)
	normal.set_border_width_all(2)
	normal.set_corner_radius_all(15)
	b.add_theme_stylebox_override("normal", normal)
	var pressed := normal.duplicate()
	pressed.bg_color = Color(0.08,0.45,0.38,0.92)
	b.add_theme_stylebox_override("pressed", pressed)
	b.set_anchors_and_offsets_preset(preset)
	b.position = offset
	b.button_down.connect(func(): touch_controls[action] = true)
	b.button_up.connect(func(): touch_controls[action] = false)
	parent.add_child(b)
