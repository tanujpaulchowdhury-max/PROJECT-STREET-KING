from pathlib import Path
import re, sys
root = Path(__file__).resolve().parents[1]
errors=[]
project=(root/'project.godot').read_text()
scene=(root/'scenes/main.tscn').read_text()
if 'run/main_scene="res://scenes/main.tscn"' not in project: errors.append('main scene setting missing')
for p in re.findall(r'path="res://([^"]+)"', scene):
    if not (root/p).exists(): errors.append(f'scene resource missing: {p}')
main=(root/'scripts/main.gd').read_text()
for script in re.findall(r'preload\("res://([^"]+)"\)', main):
    if not (root/script).exists(): errors.append(f'preloaded script missing: {script}')
for f in (root/'scripts').glob('*.gd'):
    data=f.read_text()
    if '\t' not in data and '\n' in data: errors.append(f'{f.name}: suspicious indentation (no tabs found)')
    if data.count('(')!=data.count(')'): errors.append(f'{f.name}: parenthesis count mismatch')
    if data.count('[')!=data.count(']'): errors.append(f'{f.name}: bracket count mismatch')
if errors:
    print('SOURCE CHECK FAILED')
    print('\n'.join(errors))
    sys.exit(1)
print('SOURCE CHECK PASSED')
print('Main scene and all referenced scripts exist; basic delimiter checks passed.')
print('NOTE: This is not a Godot parser or runtime test.')
