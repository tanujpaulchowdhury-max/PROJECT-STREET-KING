# Build an APK without installing Godot on your phone

This project includes a GitHub Actions workflow that attempts to build the Android APK in GitHub's cloud using the Godot CI container. You do not need to install Godot locally. A GitHub account is required, and the workflow/build may still need fixes if the engine or export configuration reports errors.

## Steps
1. Sign in to GitHub and create a new repository named `project-street-king`.
2. Upload the contents of this folder to the repository's `main` branch (make sure `.github/workflows/build-android.yml` is included).
3. Open the repository's **Actions** tab and select **Build Android APK**.
4. If it has not run automatically, select **Run workflow**.
5. Wait for the workflow to finish. If it succeeds, open the completed run and download the artifact named `PROJECT_STREET_KING-Android-APK`.
6. Extract the artifact ZIP on your phone and tap the `.apk` file to install it. Android may ask you to allow installs from that browser or file manager. Only install APKs you built and trust.

This is an unsigned-for-release prototype build workflow, not a Play Store release. It has not yet been run or validated in this environment. If the workflow fails, open the failed run's log and use the error to correct the project before trying again.
